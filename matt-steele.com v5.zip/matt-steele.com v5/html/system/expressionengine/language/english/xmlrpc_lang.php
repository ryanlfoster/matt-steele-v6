<?php

$lang = array(

'invalid_license' =>
'Invalid License',

''=>''
);

/* End of file xmlrpc_lang.php */
/* Location: ./system/expressionengine/language/english/xmlrpc_lang.php */