<?php

$lang = array(

'file_browser' =>
'File Browser',

'view' =>
'View',

'path_does_not_exist' => 
'The specified path does not exist',

'file_viewing_error' =>
'An error of an unknown type was encountered.',

'fp_no_files' => 
'No files available in directory.',

'fb_view_images' =>
'View Images',

'fb_view_image' =>
'View Image',

'fb_insert_file' =>
'Insert File',

'fb_insert_files' =>
'Insert Files',

'fb_select_field' =>
'Select Field',

'fb_select_files' =>
'Select Files',

'fb_non_images' =>
'* Indicates non-images.  Only images can be viewed.',

'fb_insert_link' =>
'Insert Link',

'fb_insert_links' =>
'Insert Links',

'fb_insert_url' =>
'Insert URL',

'fb_insert_urls' =>
'Insert URLs',


// IGNORE
''=>'');
/* End of file filebrowser_lang.php */
/* Location: ./system/expressionengine/language/english/filebrowser_lang.php */