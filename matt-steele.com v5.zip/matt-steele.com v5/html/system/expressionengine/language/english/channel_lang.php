<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

'channel_module_name' =>
'Channel',

'channel_module_description' =>
'Channel module',

//----------------------------------------

'channel_no_preview_template' =>
'A preview template was not specified in your tag',

'channel_must_be_logged_in' =>
'You must be a logged-in member of this site in order to perform this action.',

'channel_not_specified' =>
'You must specify a channel in order to use the entry form.',

'channel_no_action_found' =>
'Unable to load the resources needed to create the entry form',


''=>''
);

/* End of file channel_lang.php */
/* Location: ./system/expressionengine/language/english/channel_lang.php */