"use strict"; 
  $(document).ready(function(){
    $('.main-nav a').each(function() {
        if ($(this).prop('href') === window.location) {
            $(this).addClass('selected');
        }
    });
        $('.categories a, .ind-archives a').each(function() {
        if ($(this).prop('href') === window.location) {
            $(this).addClass('sub-selected');
        }
    });
        $('#show-hide-navigation').on('click',
          function() {
          $('body').toggleClass('show-nav');       
         });

          $('#top-show-hide-navigation').on('click',
          function() {
          $('body').toggleClass('show-top-nav');       
  });
});
